
  # Build YAS 2.0 Global Website

  This is a code bundle for Build YAS 2.0 Global Website. The original project is available at https://www.figma.com/design/cJjxj5uKT8S9ETkMzsGUNA/Build-YAS-2.0-Global-Website.

  ## Running the code

  Run `npm i` to install the dependencies.

  Run `npm run dev` to start the development server.
  